package stepDefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition {
	@Given("Launch the application with URL")
	public void launch_the_application_with_url() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Given("Type the Username in username input text field")
	public void type_the_username_in_username_input_text_field() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Given("Type the Password in password input text field")
	public void type_the_password_in_password_input_text_field() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Click the Submit button")
	public void click_the_submit_button() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Click on the banking Menu")
	public void click_on_the_banking_menu() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Click on the Member Account")
	public void click_on_the_member_account() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@Then("View the Available balance")
	public void view_the_available_balance() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@Given("User should Launch the application with Dashboard URL")
	public void user_should_launch_the_application_with_dashboard_url() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Given("User should click on the Notification")
	public void user_should_click_on_the_notification() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	
//	@Given("User should click on the Banking menu")
//	public void user_should_click_on_the_banking_menu() {
//	    // Write code here that turns the phrase above into concrete actions
//	    throw new io.cucumber.java.PendingException();
//	}

	@When("Click Any one from Account Summary")
	public void click_any_one_from_account_summary() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

//	@Then("In transfer details window click on print button")
//	public void in_transfer_details_window_click_on_print_button() {
//	    // Write code here that turns the phrase above into concrete actions
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	@Given("Click on the banking menu")
//	public void click_on_the_banking_menu() {
//	    // Write code here that turns the phrase above into concrete actions
//	    throw new io.cucumber.java.PendingException();
//	}

	@Given("click the show Filter button")
	public void click_the_show_filter_button() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Given("Select pick from your contact list on the user filter and select a contact")
	public void select_pick_from_your_contact_list_on_the_user_filter_and_select_a_contact() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Given("Click the peroid menu and select any one option")
	public void click_the_peroid_menu_and_select_any_one_option() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Select the Description menu and enter the values")
	public void select_the_description_menu_and_enter_the_values() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Select the From Amount menu enter the amount value")
	public void select_the_from_amount_menu_enter_the_amount_value() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Click the Filter menu and select one option")
	public void click_the_filter_menu_and_select_one_option() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Click the Direction menu and select one option")
	public void click_the_direction_menu_and_select_one_option() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Click the Transaction Number option and enter the transaction number")
	public void click_the_transaction_number_option_and_enter_the_transaction_number() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Click the Order by option and select one option")
	public void click_the_order_by_option_and_select_one_option() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Click the To Amount option and enter the value")
	public void click_the_to_amount_option_and_enter_the_value() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	
//	@Given("User should Click on the Banking Menu")
//	public void user_should_click_on_the_banking_menu() {
//	    // Write code here that turns the phrase above into concrete actions
//	    throw new io.cucumber.java.PendingException();
//	}

	@Given("Click any one from Account summery")
	public void click_any_one_from_account_summery() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	
	@Given("User should click on the banking Menu")
	public void user_should_click_on_the_banking_menu() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

//	@Given("click any one from Account summary")
//	public void click_any_one_from_account_summary() {
//	    // Write code here that turns the phrase above into concrete actions
//	    throw new io.cucumber.java.PendingException();
//	}

	@Given("in transfer details window click on print button")
	public void in_transfer_details_window_click_on_print_button() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}



	
	}


	




