package stepDefinition;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class accountInformation_Repo {
	@FindBy(xpath = "//input[@type=\"text\"]")
	public static WebElement username;
	@FindBy(xpath = "//input[@class=\"form-control ng-untouched ng-pristine ng-valid\"]")
	public static WebElement password;
	@FindBy(xpath = "//button[@class=\"btn d-flex justify-content-center align-items-center w-100 h-100 btn-primary btn-action-primary\"]")
	public static WebElement submit_btn;
	@FindBy(xpath = "(//div[@class=\"menu-text\"])[2]")
	public static WebElement bankingMenu;
	@FindBy(xpath = "(//div[@class=\"nav-item-text\"])[1]")
	public static WebElement memberAccount;
	@FindBy(xpath = "(//div[@class=\"status-value col-6 col-sm-3 positive\"])[2]")
	public static WebElement availableBalance;
	@FindBy(xpath = "(//*[@class=\"bi bi-bell\"])[2]")
	public static WebElement notification;
	@FindBy(xpath = "(//div[@class=\"avatar-container round-borders\"])[1]")
	public static WebElement accountSummary;
	@FindBy(css =  "div[class=\"heading-actions-plain-buttons\"]")
	public static WebElement print_btn;
	@FindBy(xpath = "//button[@class=\"btn\"]")
	public static WebElement showFilter_btn;
	@FindBy(css = "button[class=\"btn btn-icon ml-2\"]")
	public static WebElement contactList_btn;
	@FindBy(xpath = "(//div[@class=\"mb-2\"])[1]")
	public static WebElement selectContact_btn;
	@FindBy(xpath = "(//div[@class=\"w-100 mw-100 text-truncate pr-3\"])[1]")
	public static WebElement periodMenu;
	@FindBy(css = "a[class=\"select-option undefined level0\"]")
	public static WebElement periodMenu_clk;
	@FindBy(css = "input[class=\"form-control w-100 ng-pristine ng-valid ng-touched\"]")
	public static WebElement descriptionMenu;
	@FindBy(xpath = "(//input[@class=\"form-control text-right ng-untouched ng-pristine ng-valid\"])[1]")
	public static WebElement fromamountMenu;
	@FindBy(xpath = "(//div[@class=\"w-100 mw-100 text-truncate pr-3\"])[2]")
	public static WebElement filterMenu;
	@FindBy(xpath = "(//label[@class=\"custom-control-label\"])[1]")
	public static WebElement filterMenu_clk;
	@FindBy(xpath = "(//div[@class=\"w-100 mw-100 text-truncate pr-3\"])[3]")
	public static WebElement directionMenu;
	@FindBy(css = "a[class=\"select-option mt-1 selected\"]")
	public static WebElement directionMenu_clk;
	@FindBy(css = "input[class=\"form-control w-100 ng-pristine ng-valid ng-touched\"]")
	public static WebElement transactionMenu;
	@FindBy(xpath = "(//div[@class=\"w-100 mw-100 text-truncate pr-3\"])[4]")
	public static WebElement orderbyMenu;
	@FindBy(xpath = "(//a[@class=\"select-option undefined level0 selected\"])[2]")
	public static WebElement orderbyMenu_clk;
	@FindBy(xpath = "(//input[@class=\"form-control text-right ng-untouched ng-pristine ng-valid\"])[2]")
	public static WebElement toamountMenu;
	

}
