package StepDefinition;

import io.cucumber.java.en.Given;
public class StepDefinition {
	@Given("User should launch the application using the url {string}")
	public void user_should_launch_the_application_using_the_url(String string) {
	    
	}
}
