package StepDefinition;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Payments_Repository {
	@FindBy(xpath = "//div[text()='Payment to user']")
	public static  WebElement Payment_to_user;
	@FindBy(xpath = "//div[@class='d-flex']/button")
	public static  WebElement contactList;
	@FindBy(xpath = "//*[text()=' Car repair ']")
	public static WebElement Car_repair;
	@FindBy(id = "id_298")
	public static WebElement enterAmount;

}
