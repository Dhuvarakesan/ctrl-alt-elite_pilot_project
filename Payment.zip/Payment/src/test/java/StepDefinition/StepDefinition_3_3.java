package StepDefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class StepDefinition_3_3 {
	@Given("user should click the Payment Requests")
	public void user_should_click_the_payment_requests() {
		HelperClass.precondition();
		HelperClass.login();
		Payment_Repository.banking.click();
		Payment_Repository.payment_Requests.click();
	}
	@Given("User Should Click Send New Request")
	public void user_should_click_send_new_request() {
	    Payment_Repository.send_A_New_Request.click();
	}
	@Then("User Should Select Receiver")
	public void user_should_select_receiver() {
	    Payment_Repository.contact_List.click();
	    Payment_Repository.car_Repair.click();
	}
	@Then("User Should Enter The  Amount")
	public void user_should_enter_the_amount() {
	    Payment_Repository.amount_Request.click();
	    Payment_Repository.amount_Request.sendKeys("10");
	    Payment_Repository.description.click();
		Payment_Repository.description.sendKeys("Demo Payment");
	}
	@Then("User Should Enter The Expiration Date")
	public void user_should_enter_the_expiration_date() {
	    Payment_Repository.expiration_Date.click();
	    Payment_Repository.expiration_Date.sendKeys("11032028");
	}


}
